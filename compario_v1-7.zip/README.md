# Compario
Service to compare head-to-head stats for cricket players.

## Website
Website available at www.compario.dev

## Architecture
Coming soon.
